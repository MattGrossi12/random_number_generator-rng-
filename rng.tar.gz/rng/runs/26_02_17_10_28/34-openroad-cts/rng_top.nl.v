module rng_top (clk_i,
    req_num_i,
    rst_i,
    wr_i,
    num_to_send_o);
 input clk_i;
 input req_num_i;
 input rst_i;
 input wr_i;
 output [2:0] num_to_send_o;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire _044_;
 wire _045_;
 wire _046_;
 wire _047_;
 wire _048_;
 wire _049_;
 wire _050_;
 wire _051_;
 wire _052_;
 wire _053_;
 wire _054_;
 wire _055_;
 wire _056_;
 wire _057_;
 wire _058_;
 wire _059_;
 wire _060_;
 wire _061_;
 wire _062_;
 wire _063_;
 wire _064_;
 wire _065_;
 wire _066_;
 wire _067_;
 wire _068_;
 wire _069_;
 wire _070_;
 wire _071_;
 wire _072_;
 wire _073_;
 wire _074_;
 wire _075_;
 wire _076_;
 wire _077_;
 wire _078_;
 wire _079_;
 wire _080_;
 wire _081_;
 wire _082_;
 wire _083_;
 wire _084_;
 wire _085_;
 wire _086_;
 wire _087_;
 wire _088_;
 wire _089_;
 wire _090_;
 wire _091_;
 wire _092_;
 wire _093_;
 wire _094_;
 wire _095_;
 wire _096_;
 wire _097_;
 wire _098_;
 wire _099_;
 wire _100_;
 wire _101_;
 wire _102_;
 wire _103_;
 wire _104_;
 wire _105_;
 wire _106_;
 wire _107_;
 wire _108_;
 wire _109_;
 wire _110_;
 wire _111_;
 wire _112_;
 wire _113_;
 wire _114_;
 wire _115_;
 wire _116_;
 wire _117_;
 wire _118_;
 wire _119_;
 wire _120_;
 wire _121_;
 wire _122_;
 wire _123_;
 wire _124_;
 wire _125_;
 wire _126_;
 wire _127_;
 wire _128_;
 wire _129_;
 wire _130_;
 wire _131_;
 wire _132_;
 wire _133_;
 wire _134_;
 wire _135_;
 wire _136_;
 wire _137_;
 wire _138_;
 wire _139_;
 wire _140_;
 wire _141_;
 wire _142_;
 wire _143_;
 wire _144_;
 wire _145_;
 wire _146_;
 wire _147_;
 wire _148_;
 wire _149_;
 wire _150_;
 wire _151_;
 wire _152_;
 wire _153_;
 wire _154_;
 wire _155_;
 wire _156_;
 wire _157_;
 wire _158_;
 wire _159_;
 wire _160_;
 wire _161_;
 wire _162_;
 wire _163_;
 wire _164_;
 wire _165_;
 wire \num_i_bar[0] ;
 wire \num_i_bar[1] ;
 wire \num_i_bar[2] ;
 wire req_num_again;
 wire \rng_dp.inst.next_num_o[0] ;
 wire \rng_dp.inst.next_num_o[1] ;
 wire \rng_dp.inst.next_num_o[2] ;
 wire \rng_dp.seed_sel_i[0] ;
 wire \rng_dp.seed_sel_i[1] ;
 wire \rng_rd.mem[10][0] ;
 wire \rng_rd.mem[10][1] ;
 wire \rng_rd.mem[10][2] ;
 wire \rng_rd.mem[11][0] ;
 wire \rng_rd.mem[11][1] ;
 wire \rng_rd.mem[11][2] ;
 wire \rng_rd.mem[1][0] ;
 wire \rng_rd.mem[1][1] ;
 wire \rng_rd.mem[1][2] ;
 wire \rng_rd.mem[2][0] ;
 wire \rng_rd.mem[2][1] ;
 wire \rng_rd.mem[2][2] ;
 wire \rng_rd.mem[3][0] ;
 wire \rng_rd.mem[3][1] ;
 wire \rng_rd.mem[3][2] ;
 wire \rng_rd.mem[4][0] ;
 wire \rng_rd.mem[4][1] ;
 wire \rng_rd.mem[4][2] ;
 wire \rng_rd.mem[5][0] ;
 wire \rng_rd.mem[5][1] ;
 wire \rng_rd.mem[5][2] ;
 wire \rng_rd.mem[6][0] ;
 wire \rng_rd.mem[6][1] ;
 wire \rng_rd.mem[6][2] ;
 wire \rng_rd.mem[7][0] ;
 wire \rng_rd.mem[7][1] ;
 wire \rng_rd.mem[7][2] ;
 wire \rng_rd.mem[8][0] ;
 wire \rng_rd.mem[8][1] ;
 wire \rng_rd.mem[8][2] ;
 wire \rng_rd.mem[9][0] ;
 wire \rng_rd.mem[9][1] ;
 wire \rng_rd.mem[9][2] ;
 wire \rng_rd.vld[0] ;
 wire \rng_rd.vld[10] ;
 wire \rng_rd.vld[11] ;
 wire \rng_rd.vld[1] ;
 wire \rng_rd.vld[2] ;
 wire \rng_rd.vld[3] ;
 wire \rng_rd.vld[4] ;
 wire \rng_rd.vld[5] ;
 wire \rng_rd.vld[6] ;
 wire \rng_rd.vld[7] ;
 wire \rng_rd.vld[8] ;
 wire \rng_rd.vld[9] ;
 wire \rng_rd.wr_ff1 ;
 wire \rng_rd.wr_ff2 ;
 wire \rng_rd.wr_ff2_d ;
 wire \rng_rd.wr_pulse ;
 wire net1;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire net10;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire net19;
 wire net20;
 wire net21;
 wire net22;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire clknet_0_clk_i;
 wire clknet_3_0__leaf_clk_i;
 wire clknet_3_1__leaf_clk_i;
 wire clknet_3_2__leaf_clk_i;
 wire clknet_3_3__leaf_clk_i;
 wire clknet_3_4__leaf_clk_i;
 wire clknet_3_5__leaf_clk_i;
 wire clknet_3_6__leaf_clk_i;
 wire clknet_3_7__leaf_clk_i;

 sky130_fd_sc_hd__inv_2 _166_ (.A(\num_i_bar[0] ),
    .Y(_057_));
 sky130_fd_sc_hd__inv_2 _167_ (.A(\rng_rd.mem[7][1] ),
    .Y(_058_));
 sky130_fd_sc_hd__inv_2 _168_ (.A(net18),
    .Y(_059_));
 sky130_fd_sc_hd__inv_2 _169_ (.A(net16),
    .Y(_060_));
 sky130_fd_sc_hd__inv_2 _170_ (.A(\rng_rd.mem[9][0] ),
    .Y(_061_));
 sky130_fd_sc_hd__inv_2 _171_ (.A(\rng_rd.mem[10][1] ),
    .Y(_062_));
 sky130_fd_sc_hd__inv_2 _172_ (.A(\rng_rd.vld[11] ),
    .Y(_063_));
 sky130_fd_sc_hd__inv_2 _173_ (.A(\rng_dp.inst.next_num_o[0] ),
    .Y(_064_));
 sky130_fd_sc_hd__inv_2 _174_ (.A(\rng_dp.inst.next_num_o[2] ),
    .Y(_065_));
 sky130_fd_sc_hd__inv_2 _175_ (.A(\rng_dp.inst.next_num_o[1] ),
    .Y(_066_));
 sky130_fd_sc_hd__inv_2 _176_ (.A(\rng_dp.seed_sel_i[0] ),
    .Y(_001_));
 sky130_fd_sc_hd__inv_2 _177_ (.A(net4),
    .Y(_067_));
 sky130_fd_sc_hd__inv_2 _178_ (.A(\rng_rd.mem[1][1] ),
    .Y(_068_));
 sky130_fd_sc_hd__inv_2 _179_ (.A(\rng_rd.mem[3][0] ),
    .Y(_069_));
 sky130_fd_sc_hd__inv_2 _180_ (.A(\rng_rd.mem[4][0] ),
    .Y(_070_));
 sky130_fd_sc_hd__inv_2 _181_ (.A(\rng_rd.mem[5][0] ),
    .Y(_071_));
 sky130_fd_sc_hd__inv_2 _182_ (.A(\rng_rd.mem[6][1] ),
    .Y(_072_));
 sky130_fd_sc_hd__nand2_1 _183_ (.A(net13),
    .B(\rng_rd.mem[4][1] ),
    .Y(_073_));
 sky130_fd_sc_hd__o22a_1 _184_ (.A1(net14),
    .A2(\rng_rd.mem[4][0] ),
    .B1(\rng_rd.mem[4][1] ),
    .B2(net13),
    .X(_074_));
 sky130_fd_sc_hd__and2_1 _185_ (.A(net16),
    .B(\rng_rd.mem[4][2] ),
    .X(_075_));
 sky130_fd_sc_hd__nor2_1 _186_ (.A(net16),
    .B(\rng_rd.mem[4][2] ),
    .Y(_076_));
 sky130_fd_sc_hd__o221a_1 _187_ (.A1(\num_i_bar[0] ),
    .A2(_070_),
    .B1(_075_),
    .B2(_076_),
    .C1(\rng_rd.vld[4] ),
    .X(_077_));
 sky130_fd_sc_hd__and3_1 _188_ (.A(_073_),
    .B(_074_),
    .C(_077_),
    .X(_078_));
 sky130_fd_sc_hd__nand2_1 _189_ (.A(\rng_rd.mem[7][0] ),
    .B(net15),
    .Y(_079_));
 sky130_fd_sc_hd__and2_1 _190_ (.A(\rng_rd.mem[7][2] ),
    .B(net16),
    .X(_080_));
 sky130_fd_sc_hd__nor2_1 _191_ (.A(\rng_rd.mem[7][2] ),
    .B(net16),
    .Y(_081_));
 sky130_fd_sc_hd__o22a_1 _192_ (.A1(\rng_rd.mem[7][0] ),
    .A2(net15),
    .B1(\rng_rd.mem[7][1] ),
    .B2(net13),
    .X(_082_));
 sky130_fd_sc_hd__o221a_1 _193_ (.A1(_058_),
    .A2(net18),
    .B1(_080_),
    .B2(_081_),
    .C1(\rng_rd.vld[7] ),
    .X(_083_));
 sky130_fd_sc_hd__and3_1 _194_ (.A(_079_),
    .B(_082_),
    .C(_083_),
    .X(_084_));
 sky130_fd_sc_hd__a22oi_1 _195_ (.A1(net14),
    .A2(\rng_rd.mem[2][0] ),
    .B1(\rng_rd.mem[2][1] ),
    .B2(net13),
    .Y(_085_));
 sky130_fd_sc_hd__and2_1 _196_ (.A(net17),
    .B(\rng_rd.mem[2][2] ),
    .X(_086_));
 sky130_fd_sc_hd__nor2_1 _197_ (.A(net17),
    .B(\rng_rd.mem[2][2] ),
    .Y(_087_));
 sky130_fd_sc_hd__o221a_1 _198_ (.A1(net13),
    .A2(\rng_rd.mem[2][1] ),
    .B1(_086_),
    .B2(_087_),
    .C1(\rng_rd.vld[2] ),
    .X(_088_));
 sky130_fd_sc_hd__o211a_1 _199_ (.A1(net14),
    .A2(\rng_rd.mem[2][0] ),
    .B1(_085_),
    .C1(_088_),
    .X(_089_));
 sky130_fd_sc_hd__o2bb2a_1 _200_ (.A1_N(net15),
    .A2_N(\rng_rd.mem[10][0] ),
    .B1(\rng_rd.mem[10][1] ),
    .B2(net13),
    .X(_090_));
 sky130_fd_sc_hd__and2_1 _201_ (.A(net16),
    .B(\rng_rd.mem[10][2] ),
    .X(_091_));
 sky130_fd_sc_hd__nor2_1 _202_ (.A(net16),
    .B(\rng_rd.mem[10][2] ),
    .Y(_092_));
 sky130_fd_sc_hd__o221a_1 _203_ (.A1(net15),
    .A2(\rng_rd.mem[10][0] ),
    .B1(_091_),
    .B2(_092_),
    .C1(\rng_rd.vld[10] ),
    .X(_093_));
 sky130_fd_sc_hd__o211a_1 _204_ (.A1(net19),
    .A2(_062_),
    .B1(_090_),
    .C1(_093_),
    .X(_094_));
 sky130_fd_sc_hd__nor4_1 _205_ (.A(_078_),
    .B(_084_),
    .C(_089_),
    .D(_094_),
    .Y(_095_));
 sky130_fd_sc_hd__xor2_1 _206_ (.A(net17),
    .B(net6),
    .X(_096_));
 sky130_fd_sc_hd__a22o_1 _207_ (.A1(\num_i_bar[0] ),
    .A2(_067_),
    .B1(net5),
    .B2(net13),
    .X(_097_));
 sky130_fd_sc_hd__o221a_1 _208_ (.A1(\num_i_bar[0] ),
    .A2(_067_),
    .B1(net5),
    .B2(net13),
    .C1(\rng_rd.vld[0] ),
    .X(_098_));
 sky130_fd_sc_hd__or3b_1 _209_ (.A(_096_),
    .B(_097_),
    .C_N(_098_),
    .X(_099_));
 sky130_fd_sc_hd__or2_1 _210_ (.A(net19),
    .B(\rng_rd.mem[11][1] ),
    .X(_100_));
 sky130_fd_sc_hd__nand2_1 _211_ (.A(net19),
    .B(\rng_rd.mem[11][1] ),
    .Y(_101_));
 sky130_fd_sc_hd__o22ai_1 _212_ (.A1(net14),
    .A2(\rng_rd.mem[11][0] ),
    .B1(\rng_rd.mem[11][2] ),
    .B2(_060_),
    .Y(_102_));
 sky130_fd_sc_hd__a221o_1 _213_ (.A1(net14),
    .A2(\rng_rd.mem[11][0] ),
    .B1(_100_),
    .B2(_101_),
    .C1(_063_),
    .X(_103_));
 sky130_fd_sc_hd__a211o_1 _214_ (.A1(_060_),
    .A2(\rng_rd.mem[11][2] ),
    .B1(_102_),
    .C1(_103_),
    .X(_104_));
 sky130_fd_sc_hd__xor2_1 _215_ (.A(net16),
    .B(\rng_rd.mem[6][2] ),
    .X(_105_));
 sky130_fd_sc_hd__a22o_1 _216_ (.A1(net14),
    .A2(\rng_rd.mem[6][0] ),
    .B1(_072_),
    .B2(net19),
    .X(_106_));
 sky130_fd_sc_hd__o221a_1 _217_ (.A1(net14),
    .A2(\rng_rd.mem[6][0] ),
    .B1(_072_),
    .B2(net19),
    .C1(\rng_rd.vld[6] ),
    .X(_107_));
 sky130_fd_sc_hd__or3b_1 _218_ (.A(_105_),
    .B(_106_),
    .C_N(_107_),
    .X(_108_));
 sky130_fd_sc_hd__xor2_1 _219_ (.A(net16),
    .B(\rng_rd.mem[9][2] ),
    .X(_109_));
 sky130_fd_sc_hd__a22o_1 _220_ (.A1(\num_i_bar[0] ),
    .A2(_061_),
    .B1(\rng_rd.mem[9][1] ),
    .B2(net13),
    .X(_110_));
 sky130_fd_sc_hd__o221a_1 _221_ (.A1(\num_i_bar[0] ),
    .A2(_061_),
    .B1(\rng_rd.mem[9][1] ),
    .B2(net13),
    .C1(\rng_rd.vld[9] ),
    .X(_111_));
 sky130_fd_sc_hd__or3b_1 _222_ (.A(_109_),
    .B(_110_),
    .C_N(_111_),
    .X(_112_));
 sky130_fd_sc_hd__and4_1 _223_ (.A(_099_),
    .B(_104_),
    .C(_108_),
    .D(_112_),
    .X(_113_));
 sky130_fd_sc_hd__xnor2_1 _224_ (.A(net17),
    .B(\rng_rd.mem[1][2] ),
    .Y(_114_));
 sky130_fd_sc_hd__a22o_1 _225_ (.A1(net14),
    .A2(\rng_rd.mem[1][0] ),
    .B1(_068_),
    .B2(net18),
    .X(_115_));
 sky130_fd_sc_hd__o221a_1 _226_ (.A1(net14),
    .A2(\rng_rd.mem[1][0] ),
    .B1(_068_),
    .B2(net18),
    .C1(\rng_rd.vld[1] ),
    .X(_116_));
 sky130_fd_sc_hd__and3b_1 _227_ (.A_N(_115_),
    .B(_116_),
    .C(_114_),
    .X(_117_));
 sky130_fd_sc_hd__and2_1 _228_ (.A(net18),
    .B(\rng_rd.mem[3][1] ),
    .X(_118_));
 sky130_fd_sc_hd__nor2_1 _229_ (.A(net18),
    .B(\rng_rd.mem[3][1] ),
    .Y(_119_));
 sky130_fd_sc_hd__o2bb2a_1 _230_ (.A1_N(_060_),
    .A2_N(\rng_rd.mem[3][2] ),
    .B1(\rng_rd.mem[3][0] ),
    .B2(net14),
    .X(_120_));
 sky130_fd_sc_hd__o221a_1 _231_ (.A1(\num_i_bar[0] ),
    .A2(_069_),
    .B1(_118_),
    .B2(_119_),
    .C1(\rng_rd.vld[3] ),
    .X(_121_));
 sky130_fd_sc_hd__o211a_1 _232_ (.A1(_060_),
    .A2(\rng_rd.mem[3][2] ),
    .B1(_120_),
    .C1(_121_),
    .X(_122_));
 sky130_fd_sc_hd__or2_1 _233_ (.A(net15),
    .B(\rng_rd.mem[8][0] ),
    .X(_123_));
 sky130_fd_sc_hd__nor2_1 _234_ (.A(net16),
    .B(\rng_rd.mem[8][2] ),
    .Y(_124_));
 sky130_fd_sc_hd__and2_1 _235_ (.A(net17),
    .B(\rng_rd.mem[8][2] ),
    .X(_125_));
 sky130_fd_sc_hd__a22o_1 _236_ (.A1(net15),
    .A2(\rng_rd.mem[8][0] ),
    .B1(\rng_rd.mem[8][1] ),
    .B2(_059_),
    .X(_126_));
 sky130_fd_sc_hd__o221a_1 _237_ (.A1(_059_),
    .A2(\rng_rd.mem[8][1] ),
    .B1(_124_),
    .B2(_125_),
    .C1(\rng_rd.vld[8] ),
    .X(_127_));
 sky130_fd_sc_hd__and3b_1 _238_ (.A_N(_126_),
    .B(_127_),
    .C(_123_),
    .X(_128_));
 sky130_fd_sc_hd__o2bb2a_1 _239_ (.A1_N(_060_),
    .A2_N(\rng_rd.mem[5][2] ),
    .B1(\rng_rd.mem[5][0] ),
    .B2(net15),
    .X(_129_));
 sky130_fd_sc_hd__nor2_1 _240_ (.A(net18),
    .B(\rng_rd.mem[5][1] ),
    .Y(_130_));
 sky130_fd_sc_hd__and2_1 _241_ (.A(net18),
    .B(\rng_rd.mem[5][1] ),
    .X(_131_));
 sky130_fd_sc_hd__o221a_1 _242_ (.A1(\num_i_bar[0] ),
    .A2(_071_),
    .B1(_130_),
    .B2(_131_),
    .C1(\rng_rd.vld[5] ),
    .X(_132_));
 sky130_fd_sc_hd__o211a_1 _243_ (.A1(_060_),
    .A2(\rng_rd.mem[5][2] ),
    .B1(_129_),
    .C1(_132_),
    .X(_133_));
 sky130_fd_sc_hd__nor4_1 _244_ (.A(_117_),
    .B(_122_),
    .C(_128_),
    .D(_133_),
    .Y(_134_));
 sky130_fd_sc_hd__and3_1 _245_ (.A(_095_),
    .B(_113_),
    .C(_134_),
    .X(_135_));
 sky130_fd_sc_hd__or2_2 _246_ (.A(net1),
    .B(req_num_again),
    .X(_136_));
 sky130_fd_sc_hd__and2b_1 _247_ (.A_N(_135_),
    .B(_136_),
    .X(req_num_again));
 sky130_fd_sc_hd__and2b_1 _248_ (.A_N(\rng_rd.wr_ff2_d ),
    .B(\rng_rd.wr_ff2 ),
    .X(_000_));
 sky130_fd_sc_hd__or2_1 _249_ (.A(\rng_dp.seed_sel_i[1] ),
    .B(_001_),
    .X(_137_));
 sky130_fd_sc_hd__nand2_1 _250_ (.A(\rng_dp.seed_sel_i[1] ),
    .B(_001_),
    .Y(_138_));
 sky130_fd_sc_hd__nand2_1 _251_ (.A(_137_),
    .B(_138_),
    .Y(_002_));
 sky130_fd_sc_hd__and4_1 _252_ (.A(\rng_rd.wr_pulse ),
    .B(_095_),
    .C(_113_),
    .D(_134_),
    .X(_139_));
 sky130_fd_sc_hd__mux2_1 _253_ (.A0(\rng_rd.mem[11][0] ),
    .A1(\rng_rd.mem[10][0] ),
    .S(net9),
    .X(_003_));
 sky130_fd_sc_hd__mux2_1 _254_ (.A0(\rng_rd.mem[11][1] ),
    .A1(\rng_rd.mem[10][1] ),
    .S(net8),
    .X(_004_));
 sky130_fd_sc_hd__mux2_1 _255_ (.A0(\rng_rd.mem[11][2] ),
    .A1(\rng_rd.mem[10][2] ),
    .S(net8),
    .X(_005_));
 sky130_fd_sc_hd__nor2_1 _256_ (.A(_065_),
    .B(\rng_dp.inst.next_num_o[1] ),
    .Y(_140_));
 sky130_fd_sc_hd__nor2_1 _257_ (.A(\rng_dp.inst.next_num_o[0] ),
    .B(_066_),
    .Y(_141_));
 sky130_fd_sc_hd__nor2_1 _258_ (.A(\rng_dp.inst.next_num_o[0] ),
    .B(\rng_dp.inst.next_num_o[2] ),
    .Y(_142_));
 sky130_fd_sc_hd__or3_1 _259_ (.A(_138_),
    .B(_141_),
    .C(_142_),
    .X(_143_));
 sky130_fd_sc_hd__a21oi_1 _260_ (.A1(\rng_dp.inst.next_num_o[0] ),
    .A2(_140_),
    .B1(_143_),
    .Y(_144_));
 sky130_fd_sc_hd__nor2_1 _261_ (.A(_064_),
    .B(_065_),
    .Y(_145_));
 sky130_fd_sc_hd__o21ai_1 _262_ (.A1(_142_),
    .A2(_145_),
    .B1(\rng_dp.seed_sel_i[0] ),
    .Y(_146_));
 sky130_fd_sc_hd__o211a_1 _263_ (.A1(_142_),
    .A2(_145_),
    .B1(\rng_dp.seed_sel_i[1] ),
    .C1(\rng_dp.seed_sel_i[0] ),
    .X(_147_));
 sky130_fd_sc_hd__a211o_1 _264_ (.A1(_064_),
    .A2(\rng_dp.inst.next_num_o[2] ),
    .B1(\rng_dp.seed_sel_i[1] ),
    .C1(\rng_dp.seed_sel_i[0] ),
    .X(_148_));
 sky130_fd_sc_hd__a21o_1 _265_ (.A1(\rng_dp.inst.next_num_o[2] ),
    .A2(\rng_dp.inst.next_num_o[1] ),
    .B1(_137_),
    .X(_149_));
 sky130_fd_sc_hd__a22o_1 _266_ (.A1(\rng_dp.inst.next_num_o[0] ),
    .A2(_066_),
    .B1(_148_),
    .B2(_149_),
    .X(_150_));
 sky130_fd_sc_hd__nand2_1 _267_ (.A(_136_),
    .B(_150_),
    .Y(_151_));
 sky130_fd_sc_hd__o32a_1 _268_ (.A1(_144_),
    .A2(_147_),
    .A3(_151_),
    .B1(_136_),
    .B2(\num_i_bar[0] ),
    .X(_006_));
 sky130_fd_sc_hd__or2_1 _269_ (.A(_138_),
    .B(_140_),
    .X(_152_));
 sky130_fd_sc_hd__a22o_1 _270_ (.A1(_065_),
    .A2(\rng_dp.inst.next_num_o[1] ),
    .B1(_148_),
    .B2(_152_),
    .X(_153_));
 sky130_fd_sc_hd__nor2_1 _271_ (.A(\rng_dp.inst.next_num_o[2] ),
    .B(_141_),
    .Y(_154_));
 sky130_fd_sc_hd__a211o_1 _272_ (.A1(\rng_dp.inst.next_num_o[0] ),
    .A2(_066_),
    .B1(_137_),
    .C1(_154_),
    .X(_155_));
 sky130_fd_sc_hd__nand2_1 _273_ (.A(\rng_dp.seed_sel_i[1] ),
    .B(\rng_dp.seed_sel_i[0] ),
    .Y(_156_));
 sky130_fd_sc_hd__o311a_1 _274_ (.A1(_140_),
    .A2(_141_),
    .A3(_156_),
    .B1(_155_),
    .C1(_136_),
    .X(_157_));
 sky130_fd_sc_hd__o2bb2a_1 _275_ (.A1_N(_157_),
    .A2_N(_153_),
    .B1(_136_),
    .B2(net18),
    .X(_007_));
 sky130_fd_sc_hd__o21a_1 _276_ (.A1(_142_),
    .A2(_145_),
    .B1(\rng_dp.inst.next_num_o[1] ),
    .X(_158_));
 sky130_fd_sc_hd__or4_1 _277_ (.A(\rng_dp.seed_sel_i[1] ),
    .B(\rng_dp.seed_sel_i[0] ),
    .C(_140_),
    .D(_158_),
    .X(_159_));
 sky130_fd_sc_hd__nand2_1 _278_ (.A(\rng_dp.inst.next_num_o[2] ),
    .B(\rng_dp.seed_sel_i[1] ),
    .Y(_160_));
 sky130_fd_sc_hd__a32o_1 _279_ (.A1(_146_),
    .A2(_159_),
    .A3(_160_),
    .B1(\rng_dp.seed_sel_i[0] ),
    .B2(\rng_dp.seed_sel_i[1] ),
    .X(_161_));
 sky130_fd_sc_hd__nor2_1 _280_ (.A(\rng_dp.inst.next_num_o[1] ),
    .B(_145_),
    .Y(_162_));
 sky130_fd_sc_hd__o31a_1 _281_ (.A1(_142_),
    .A2(_156_),
    .A3(_162_),
    .B1(_136_),
    .X(_163_));
 sky130_fd_sc_hd__o2bb2a_1 _282_ (.A1_N(_163_),
    .A2_N(_161_),
    .B1(_136_),
    .B2(net17),
    .X(_008_));
 sky130_fd_sc_hd__mux2_1 _283_ (.A0(\rng_rd.mem[7][0] ),
    .A1(\rng_rd.mem[6][0] ),
    .S(net11),
    .X(_009_));
 sky130_fd_sc_hd__mux2_1 _284_ (.A0(\rng_rd.mem[7][1] ),
    .A1(\rng_rd.mem[6][1] ),
    .S(net11),
    .X(_010_));
 sky130_fd_sc_hd__mux2_1 _285_ (.A0(\rng_rd.mem[7][2] ),
    .A1(\rng_rd.mem[6][2] ),
    .S(net11),
    .X(_011_));
 sky130_fd_sc_hd__mux2_1 _286_ (.A0(\rng_rd.mem[10][0] ),
    .A1(\rng_rd.mem[9][0] ),
    .S(net9),
    .X(_012_));
 sky130_fd_sc_hd__mux2_1 _287_ (.A0(\rng_rd.mem[10][1] ),
    .A1(\rng_rd.mem[9][1] ),
    .S(net9),
    .X(_013_));
 sky130_fd_sc_hd__mux2_1 _288_ (.A0(\rng_rd.mem[10][2] ),
    .A1(\rng_rd.mem[9][2] ),
    .S(net9),
    .X(_014_));
 sky130_fd_sc_hd__mux2_1 _289_ (.A0(\rng_rd.mem[6][0] ),
    .A1(\rng_rd.mem[5][0] ),
    .S(net10),
    .X(_015_));
 sky130_fd_sc_hd__mux2_1 _290_ (.A0(\rng_rd.mem[6][1] ),
    .A1(\rng_rd.mem[5][1] ),
    .S(net10),
    .X(_016_));
 sky130_fd_sc_hd__mux2_1 _291_ (.A0(\rng_rd.mem[6][2] ),
    .A1(\rng_rd.mem[5][2] ),
    .S(net10),
    .X(_017_));
 sky130_fd_sc_hd__mux2_1 _292_ (.A0(\rng_rd.mem[5][0] ),
    .A1(\rng_rd.mem[4][0] ),
    .S(net10),
    .X(_018_));
 sky130_fd_sc_hd__mux2_1 _293_ (.A0(\rng_rd.mem[5][1] ),
    .A1(\rng_rd.mem[4][1] ),
    .S(net10),
    .X(_019_));
 sky130_fd_sc_hd__mux2_1 _294_ (.A0(\rng_rd.mem[5][2] ),
    .A1(\rng_rd.mem[4][2] ),
    .S(net10),
    .X(_020_));
 sky130_fd_sc_hd__mux2_1 _295_ (.A0(\rng_rd.mem[4][0] ),
    .A1(\rng_rd.mem[3][0] ),
    .S(net12),
    .X(_021_));
 sky130_fd_sc_hd__mux2_1 _296_ (.A0(\rng_rd.mem[4][1] ),
    .A1(\rng_rd.mem[3][1] ),
    .S(net12),
    .X(_022_));
 sky130_fd_sc_hd__mux2_1 _297_ (.A0(\rng_rd.mem[4][2] ),
    .A1(\rng_rd.mem[3][2] ),
    .S(net8),
    .X(_023_));
 sky130_fd_sc_hd__mux2_1 _298_ (.A0(\rng_rd.mem[3][0] ),
    .A1(\rng_rd.mem[2][0] ),
    .S(net7),
    .X(_024_));
 sky130_fd_sc_hd__mux2_1 _299_ (.A0(\rng_rd.mem[3][1] ),
    .A1(\rng_rd.mem[2][1] ),
    .S(net12),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _300_ (.A0(\rng_rd.mem[3][2] ),
    .A1(\rng_rd.mem[2][2] ),
    .S(net8),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _301_ (.A0(\rng_rd.mem[2][0] ),
    .A1(\rng_rd.mem[1][0] ),
    .S(net7),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _302_ (.A0(\rng_rd.mem[2][1] ),
    .A1(\rng_rd.mem[1][1] ),
    .S(net7),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _303_ (.A0(\rng_rd.mem[2][2] ),
    .A1(\rng_rd.mem[1][2] ),
    .S(net8),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _304_ (.A0(\rng_rd.mem[1][0] ),
    .A1(net4),
    .S(net7),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _305_ (.A0(\rng_rd.mem[1][1] ),
    .A1(net5),
    .S(net7),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _306_ (.A0(\rng_rd.mem[1][2] ),
    .A1(net6),
    .S(net8),
    .X(_032_));
 sky130_fd_sc_hd__mux2_1 _307_ (.A0(net4),
    .A1(\num_i_bar[0] ),
    .S(net7),
    .X(_033_));
 sky130_fd_sc_hd__mux2_1 _308_ (.A0(net5),
    .A1(net18),
    .S(net8),
    .X(_034_));
 sky130_fd_sc_hd__mux2_1 _309_ (.A0(net6),
    .A1(net17),
    .S(net8),
    .X(_035_));
 sky130_fd_sc_hd__or2_1 _310_ (.A(\rng_rd.vld[0] ),
    .B(net7),
    .X(_036_));
 sky130_fd_sc_hd__mux2_1 _311_ (.A0(\rng_rd.vld[1] ),
    .A1(\rng_rd.vld[0] ),
    .S(net7),
    .X(_037_));
 sky130_fd_sc_hd__mux2_1 _312_ (.A0(\rng_rd.vld[2] ),
    .A1(\rng_rd.vld[1] ),
    .S(net7),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _313_ (.A0(\rng_rd.vld[3] ),
    .A1(\rng_rd.vld[2] ),
    .S(net7),
    .X(_039_));
 sky130_fd_sc_hd__mux2_1 _314_ (.A0(\rng_rd.vld[4] ),
    .A1(\rng_rd.vld[3] ),
    .S(net8),
    .X(_040_));
 sky130_fd_sc_hd__mux2_1 _315_ (.A0(\rng_rd.vld[5] ),
    .A1(\rng_rd.vld[4] ),
    .S(net10),
    .X(_041_));
 sky130_fd_sc_hd__mux2_1 _316_ (.A0(\rng_rd.vld[6] ),
    .A1(\rng_rd.vld[5] ),
    .S(net10),
    .X(_042_));
 sky130_fd_sc_hd__mux2_1 _317_ (.A0(\rng_rd.vld[7] ),
    .A1(\rng_rd.vld[6] ),
    .S(net11),
    .X(_043_));
 sky130_fd_sc_hd__mux2_1 _318_ (.A0(\rng_rd.vld[8] ),
    .A1(\rng_rd.vld[7] ),
    .S(net9),
    .X(_044_));
 sky130_fd_sc_hd__mux2_1 _319_ (.A0(\rng_rd.vld[9] ),
    .A1(\rng_rd.vld[8] ),
    .S(net11),
    .X(_045_));
 sky130_fd_sc_hd__mux2_1 _320_ (.A0(\rng_rd.vld[10] ),
    .A1(\rng_rd.vld[9] ),
    .S(net9),
    .X(_046_));
 sky130_fd_sc_hd__mux2_1 _321_ (.A0(\rng_rd.vld[11] ),
    .A1(\rng_rd.vld[10] ),
    .S(net9),
    .X(_047_));
 sky130_fd_sc_hd__mux2_1 _322_ (.A0(\rng_rd.mem[8][0] ),
    .A1(\rng_rd.mem[7][0] ),
    .S(net10),
    .X(_048_));
 sky130_fd_sc_hd__mux2_1 _323_ (.A0(\rng_rd.mem[8][1] ),
    .A1(\rng_rd.mem[7][1] ),
    .S(net10),
    .X(_049_));
 sky130_fd_sc_hd__mux2_1 _324_ (.A0(\rng_rd.mem[8][2] ),
    .A1(\rng_rd.mem[7][2] ),
    .S(net9),
    .X(_050_));
 sky130_fd_sc_hd__xnor2_1 _325_ (.A(_064_),
    .B(_136_),
    .Y(_051_));
 sky130_fd_sc_hd__and3_1 _326_ (.A(\rng_dp.inst.next_num_o[0] ),
    .B(\rng_dp.inst.next_num_o[1] ),
    .C(_136_),
    .X(_164_));
 sky130_fd_sc_hd__a21oi_1 _327_ (.A1(\rng_dp.inst.next_num_o[0] ),
    .A2(_136_),
    .B1(\rng_dp.inst.next_num_o[1] ),
    .Y(_165_));
 sky130_fd_sc_hd__nor2_1 _328_ (.A(_164_),
    .B(_165_),
    .Y(_052_));
 sky130_fd_sc_hd__xnor2_1 _329_ (.A(_065_),
    .B(_164_),
    .Y(_053_));
 sky130_fd_sc_hd__mux2_1 _330_ (.A0(\rng_rd.mem[9][0] ),
    .A1(\rng_rd.mem[8][0] ),
    .S(net11),
    .X(_054_));
 sky130_fd_sc_hd__mux2_1 _331_ (.A0(\rng_rd.mem[9][1] ),
    .A1(\rng_rd.mem[8][1] ),
    .S(net9),
    .X(_055_));
 sky130_fd_sc_hd__mux2_1 _332_ (.A0(\rng_rd.mem[9][2] ),
    .A1(\rng_rd.mem[8][2] ),
    .S(net9),
    .X(_056_));
 sky130_fd_sc_hd__dfrtp_1 _333_ (.CLK(clknet_3_4__leaf_clk_i),
    .D(_003_),
    .RESET_B(net24),
    .Q(\rng_rd.mem[11][0] ));
 sky130_fd_sc_hd__dfrtp_1 _334_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(_004_),
    .RESET_B(net20),
    .Q(\rng_rd.mem[11][1] ));
 sky130_fd_sc_hd__dfrtp_1 _335_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(_005_),
    .RESET_B(net20),
    .Q(\rng_rd.mem[11][2] ));
 sky130_fd_sc_hd__dfrtp_4 _336_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(_006_),
    .RESET_B(net20),
    .Q(\num_i_bar[0] ));
 sky130_fd_sc_hd__dfrtp_1 _337_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(_007_),
    .RESET_B(net21),
    .Q(\num_i_bar[1] ));
 sky130_fd_sc_hd__dfrtp_1 _338_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_008_),
    .RESET_B(net20),
    .Q(\num_i_bar[2] ));
 sky130_fd_sc_hd__dfrtp_2 _339_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_001_),
    .RESET_B(net20),
    .Q(\rng_dp.seed_sel_i[0] ));
 sky130_fd_sc_hd__dfrtp_2 _340_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_002_),
    .RESET_B(net20),
    .Q(\rng_dp.seed_sel_i[1] ));
 sky130_fd_sc_hd__dfrtp_1 _341_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_009_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[7][0] ));
 sky130_fd_sc_hd__dfrtp_1 _342_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_010_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[7][1] ));
 sky130_fd_sc_hd__dfrtp_1 _343_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_011_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[7][2] ));
 sky130_fd_sc_hd__dfrtp_1 _344_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_012_),
    .RESET_B(net24),
    .Q(\rng_rd.mem[10][0] ));
 sky130_fd_sc_hd__dfrtp_1 _345_ (.CLK(clknet_3_4__leaf_clk_i),
    .D(_013_),
    .RESET_B(net24),
    .Q(\rng_rd.mem[10][1] ));
 sky130_fd_sc_hd__dfrtp_1 _346_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_014_),
    .RESET_B(net24),
    .Q(\rng_rd.mem[10][2] ));
 sky130_fd_sc_hd__dfrtp_1 _347_ (.CLK(clknet_3_6__leaf_clk_i),
    .D(_015_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[6][0] ));
 sky130_fd_sc_hd__dfrtp_1 _348_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_016_),
    .RESET_B(net26),
    .Q(\rng_rd.mem[6][1] ));
 sky130_fd_sc_hd__dfrtp_1 _349_ (.CLK(clknet_3_6__leaf_clk_i),
    .D(_017_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[6][2] ));
 sky130_fd_sc_hd__dfrtp_1 _350_ (.CLK(clknet_3_6__leaf_clk_i),
    .D(_018_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[5][0] ));
 sky130_fd_sc_hd__dfrtp_1 _351_ (.CLK(clknet_3_6__leaf_clk_i),
    .D(_019_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[5][1] ));
 sky130_fd_sc_hd__dfrtp_1 _352_ (.CLK(clknet_3_6__leaf_clk_i),
    .D(_020_),
    .RESET_B(net25),
    .Q(\rng_rd.mem[5][2] ));
 sky130_fd_sc_hd__dfrtp_1 _353_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_021_),
    .RESET_B(net22),
    .Q(\rng_rd.mem[4][0] ));
 sky130_fd_sc_hd__dfrtp_1 _354_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_022_),
    .RESET_B(net22),
    .Q(\rng_rd.mem[4][1] ));
 sky130_fd_sc_hd__dfrtp_1 _355_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_023_),
    .RESET_B(net23),
    .Q(\rng_rd.mem[4][2] ));
 sky130_fd_sc_hd__dfrtp_1 _356_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(net3),
    .RESET_B(net20),
    .Q(\rng_rd.wr_ff1 ));
 sky130_fd_sc_hd__dfrtp_1 _357_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_024_),
    .RESET_B(net23),
    .Q(\rng_rd.mem[3][0] ));
 sky130_fd_sc_hd__dfrtp_1 _358_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_025_),
    .RESET_B(net23),
    .Q(\rng_rd.mem[3][1] ));
 sky130_fd_sc_hd__dfrtp_1 _359_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_026_),
    .RESET_B(net23),
    .Q(\rng_rd.mem[3][2] ));
 sky130_fd_sc_hd__dfrtp_1 _360_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_027_),
    .RESET_B(net23),
    .Q(\rng_rd.mem[2][0] ));
 sky130_fd_sc_hd__dfrtp_1 _361_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_028_),
    .RESET_B(net22),
    .Q(\rng_rd.mem[2][1] ));
 sky130_fd_sc_hd__dfrtp_1 _362_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_029_),
    .RESET_B(net21),
    .Q(\rng_rd.mem[2][2] ));
 sky130_fd_sc_hd__dfrtp_1 _363_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_030_),
    .RESET_B(net22),
    .Q(\rng_rd.mem[1][0] ));
 sky130_fd_sc_hd__dfrtp_1 _364_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_031_),
    .RESET_B(net22),
    .Q(\rng_rd.mem[1][1] ));
 sky130_fd_sc_hd__dfrtp_1 _365_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_032_),
    .RESET_B(net20),
    .Q(\rng_rd.mem[1][2] ));
 sky130_fd_sc_hd__dfrtp_1 _366_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(\rng_rd.wr_ff1 ),
    .RESET_B(net20),
    .Q(\rng_rd.wr_ff2 ));
 sky130_fd_sc_hd__dfrtp_1 _367_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_033_),
    .RESET_B(net22),
    .Q(net4));
 sky130_fd_sc_hd__dfrtp_1 _368_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_034_),
    .RESET_B(net22),
    .Q(net5));
 sky130_fd_sc_hd__dfrtp_1 _369_ (.CLK(clknet_3_0__leaf_clk_i),
    .D(_035_),
    .RESET_B(net20),
    .Q(net6));
 sky130_fd_sc_hd__dfrtp_1 _370_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_036_),
    .RESET_B(net22),
    .Q(\rng_rd.vld[0] ));
 sky130_fd_sc_hd__dfrtp_1 _371_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_037_),
    .RESET_B(net22),
    .Q(\rng_rd.vld[1] ));
 sky130_fd_sc_hd__dfrtp_1 _372_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_038_),
    .RESET_B(net22),
    .Q(\rng_rd.vld[2] ));
 sky130_fd_sc_hd__dfrtp_1 _373_ (.CLK(clknet_3_2__leaf_clk_i),
    .D(_039_),
    .RESET_B(net23),
    .Q(\rng_rd.vld[3] ));
 sky130_fd_sc_hd__dfrtp_1 _374_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_040_),
    .RESET_B(net23),
    .Q(\rng_rd.vld[4] ));
 sky130_fd_sc_hd__dfrtp_1 _375_ (.CLK(clknet_3_3__leaf_clk_i),
    .D(_041_),
    .RESET_B(net25),
    .Q(\rng_rd.vld[5] ));
 sky130_fd_sc_hd__dfrtp_1 _376_ (.CLK(clknet_3_6__leaf_clk_i),
    .D(_042_),
    .RESET_B(net25),
    .Q(\rng_rd.vld[6] ));
 sky130_fd_sc_hd__dfrtp_1 _377_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_043_),
    .RESET_B(net26),
    .Q(\rng_rd.vld[7] ));
 sky130_fd_sc_hd__dfrtp_1 _378_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_044_),
    .RESET_B(net24),
    .Q(\rng_rd.vld[8] ));
 sky130_fd_sc_hd__dfrtp_1 _379_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_045_),
    .RESET_B(net24),
    .Q(\rng_rd.vld[9] ));
 sky130_fd_sc_hd__dfrtp_1 _380_ (.CLK(clknet_3_4__leaf_clk_i),
    .D(_046_),
    .RESET_B(net24),
    .Q(\rng_rd.vld[10] ));
 sky130_fd_sc_hd__dfrtp_1 _381_ (.CLK(clknet_3_4__leaf_clk_i),
    .D(_047_),
    .RESET_B(net24),
    .Q(\rng_rd.vld[11] ));
 sky130_fd_sc_hd__dfrtp_1 _382_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_048_),
    .RESET_B(net26),
    .Q(\rng_rd.mem[8][0] ));
 sky130_fd_sc_hd__dfrtp_1 _383_ (.CLK(clknet_3_7__leaf_clk_i),
    .D(_049_),
    .RESET_B(net26),
    .Q(\rng_rd.mem[8][1] ));
 sky130_fd_sc_hd__dfrtp_1 _384_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_050_),
    .RESET_B(net24),
    .Q(\rng_rd.mem[8][2] ));
 sky130_fd_sc_hd__dfrtp_1 _385_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(\rng_rd.wr_ff2 ),
    .RESET_B(net21),
    .Q(\rng_rd.wr_ff2_d ));
 sky130_fd_sc_hd__dfrtp_4 _386_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(_051_),
    .RESET_B(net21),
    .Q(\rng_dp.inst.next_num_o[0] ));
 sky130_fd_sc_hd__dfrtp_4 _387_ (.CLK(clknet_3_4__leaf_clk_i),
    .D(_052_),
    .RESET_B(net21),
    .Q(\rng_dp.inst.next_num_o[1] ));
 sky130_fd_sc_hd__dfrtp_2 _388_ (.CLK(clknet_3_4__leaf_clk_i),
    .D(_053_),
    .RESET_B(net21),
    .Q(\rng_dp.inst.next_num_o[2] ));
 sky130_fd_sc_hd__dfrtp_1 _389_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_054_),
    .RESET_B(net24),
    .Q(\rng_rd.mem[9][0] ));
 sky130_fd_sc_hd__dfrtp_1 _390_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_055_),
    .RESET_B(net26),
    .Q(\rng_rd.mem[9][1] ));
 sky130_fd_sc_hd__dfrtp_1 _391_ (.CLK(clknet_3_5__leaf_clk_i),
    .D(_056_),
    .RESET_B(net26),
    .Q(\rng_rd.mem[9][2] ));
 sky130_fd_sc_hd__dfrtp_1 _392_ (.CLK(clknet_3_1__leaf_clk_i),
    .D(_000_),
    .RESET_B(net21),
    .Q(\rng_rd.wr_pulse ));
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Right_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Right_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Right_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Right_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Right_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Right_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Right_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Right_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Right_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Right_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Right_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Right_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Right_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Right_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Right_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Right_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Right_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_34 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_35 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_36 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_37 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_38 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_39 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_40 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_41 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_42 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_43 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_44 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_45 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_46 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_47 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_48 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_49 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_50 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_17_Left_51 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_18_Left_52 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_19_Left_53 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_20_Left_54 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_21_Left_55 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_22_Left_56 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_23_Left_57 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_24_Left_58 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_25_Left_59 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_26_Left_60 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_27_Left_61 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_28_Left_62 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_29_Left_63 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_30_Left_64 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_31_Left_65 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_32_Left_66 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_33_Left_67 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_68 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_69 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_70 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_71 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_72 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_73 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_74 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_75 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_76 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_77 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_78 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_79 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_80 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_81 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_82 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_83 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_84 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_85 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_86 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_87 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_88 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_89 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_90 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_91 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_92 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_93 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_94 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_95 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_96 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_97 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_98 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_99 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_100 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_101 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_102 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_103 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_104 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_105 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_106 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_107 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_108 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_109 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_110 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_111 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_112 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_113 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_114 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_115 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_116 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_117 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_118 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_119 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_120 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_121 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_122 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_123 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_124 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_125 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_126 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_127 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_128 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_129 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_130 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_131 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_132 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_17_133 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_134 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_135 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_136 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_18_137 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_138 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_139 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_19_140 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_141 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_142 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_143 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_20_144 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_145 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_146 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_21_147 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_148 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_149 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_150 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_22_151 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_152 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_153 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_23_154 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_155 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_156 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_157 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_24_158 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_159 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_160 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_25_161 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_162 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_163 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_164 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_26_165 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_166 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_167 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_27_168 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_169 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_170 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_171 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_28_172 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_173 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_174 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_29_175 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_176 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_177 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_178 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_30_179 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_180 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_181 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_31_182 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_183 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_184 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_185 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_32_186 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_187 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_188 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_189 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_190 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_191 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_192 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_33_193 ();
 sky130_fd_sc_hd__clkbuf_1 input1 (.A(req_num_i),
    .X(net1));
 sky130_fd_sc_hd__clkbuf_1 input2 (.A(rst_i),
    .X(net2));
 sky130_fd_sc_hd__clkbuf_1 input3 (.A(wr_i),
    .X(net3));
 sky130_fd_sc_hd__buf_2 output4 (.A(net4),
    .X(num_to_send_o[0]));
 sky130_fd_sc_hd__buf_2 output5 (.A(net5),
    .X(num_to_send_o[1]));
 sky130_fd_sc_hd__buf_2 output6 (.A(net6),
    .X(num_to_send_o[2]));
 sky130_fd_sc_hd__clkbuf_4 fanout7 (.A(net8),
    .X(net7));
 sky130_fd_sc_hd__clkbuf_4 fanout8 (.A(net12),
    .X(net8));
 sky130_fd_sc_hd__clkbuf_4 fanout9 (.A(net11),
    .X(net9));
 sky130_fd_sc_hd__clkbuf_4 fanout10 (.A(net11),
    .X(net10));
 sky130_fd_sc_hd__buf_2 fanout11 (.A(net12),
    .X(net11));
 sky130_fd_sc_hd__clkbuf_2 fanout12 (.A(_139_),
    .X(net12));
 sky130_fd_sc_hd__buf_2 fanout13 (.A(_059_),
    .X(net13));
 sky130_fd_sc_hd__buf_2 fanout14 (.A(_057_),
    .X(net14));
 sky130_fd_sc_hd__clkbuf_2 fanout15 (.A(_057_),
    .X(net15));
 sky130_fd_sc_hd__clkbuf_4 fanout16 (.A(net17),
    .X(net16));
 sky130_fd_sc_hd__buf_2 fanout17 (.A(\num_i_bar[2] ),
    .X(net17));
 sky130_fd_sc_hd__buf_2 fanout18 (.A(\num_i_bar[1] ),
    .X(net18));
 sky130_fd_sc_hd__dlymetal6s2s_1 fanout19 (.A(\num_i_bar[1] ),
    .X(net19));
 sky130_fd_sc_hd__clkbuf_4 fanout20 (.A(net27),
    .X(net20));
 sky130_fd_sc_hd__buf_2 fanout21 (.A(net27),
    .X(net21));
 sky130_fd_sc_hd__clkbuf_4 fanout22 (.A(net27),
    .X(net22));
 sky130_fd_sc_hd__buf_2 fanout23 (.A(net27),
    .X(net23));
 sky130_fd_sc_hd__clkbuf_4 fanout24 (.A(net26),
    .X(net24));
 sky130_fd_sc_hd__clkbuf_4 fanout25 (.A(net26),
    .X(net25));
 sky130_fd_sc_hd__buf_2 fanout26 (.A(net27),
    .X(net26));
 sky130_fd_sc_hd__dlymetal6s2s_1 fanout27 (.A(net2),
    .X(net27));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_clk_i (.A(clk_i),
    .X(clknet_0_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_0__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_0__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_1__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_1__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_2__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_2__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_3__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_3__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_4__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_4__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_5__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_5__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_6__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_6__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_3_7__f_clk_i (.A(clknet_0_clk_i),
    .X(clknet_3_7__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_4 clkload0 (.A(clknet_3_0__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_8 clkload1 (.A(clknet_3_1__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_4 clkload2 (.A(clknet_3_3__leaf_clk_i));
 sky130_fd_sc_hd__clkinv_2 clkload3 (.A(clknet_3_4__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_4 clkload4 (.A(clknet_3_5__leaf_clk_i));
 sky130_fd_sc_hd__clkinv_2 clkload5 (.A(clknet_3_6__leaf_clk_i));
 sky130_fd_sc_hd__clkbuf_8 clkload6 (.A(clknet_3_7__leaf_clk_i));
endmodule
